# IMIDUS POS Integration - Local Development Starter
# Run with: PowerShell -ExecutionPolicy Bypass -File START.ps1

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  IMIDUS POS Integration - Local Dev" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check prerequisites
Write-Host "Checking prerequisites..." -ForegroundColor Yellow

try {
    $dockerVersion = docker --version 2>$null
    if (-not $dockerVersion) {
        throw "Docker not found"
    }
    Write-Host "✓ Docker found: $dockerVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Docker is not installed" -ForegroundColor Red
    Write-Host "Please install Docker Desktop from: https://docs.docker.com/get-docker/"
    Read-Host "Press Enter to exit"
    exit 1
}

try {
    $composeVersion = docker-compose --version 2>$null
    if (-not $composeVersion) {
        throw "Docker Compose not found"
    }
    Write-Host "✓ Docker Compose found: $composeVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Docker Compose is not installed" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "[1/3] Starting Docker services..." -ForegroundColor Yellow
docker-compose up -d

Write-Host "[2/3] Waiting for SQL Server (30 seconds)..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

Write-Host "[3/3] Checking database..." -ForegroundColor Yellow
$dbCheck = docker exec imidus-sqlserver /opt/mssql-tools18/bin/sqlcmd `
    -S localhost -U sa -P "YourStrong@Passw0rd" -C `
    -Q "SELECT COUNT(*) FROM sys.databases WHERE name = 'INI_Restaurant'" 2>$null

if ($dbCheck -match "0" -or -not $dbCheck) {
    Write-Host "Database not found. Restoring from backup..." -ForegroundColor Yellow
    if (Test-Path "scripts/restore-database.sh") {
        bash scripts/restore-database.sh
    } else {
        Write-Host "⚠ Restore script not found. Database may need manual restore." -ForegroundColor Yellow
    }
} else {
    Write-Host "✓ Database already restored" -ForegroundColor Green
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
Write-Host "  ✓ Services Ready!" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Backend API:    http://localhost:5004" -ForegroundColor Cyan
Write-Host "Health Check:   http://localhost:5004/health" -ForegroundColor Cyan
Write-Host "Swagger UI:     http://localhost:5004/swagger" -ForegroundColor Cyan
Write-Host "Database UI:    http://localhost:8080" -ForegroundColor Cyan
Write-Host ""

$openBrowser = Read-Host "Open Swagger UI in browser? (Y/n)"
if ($openBrowser -ne 'n') {
    Start-Process "http://localhost:5004/swagger"
}
