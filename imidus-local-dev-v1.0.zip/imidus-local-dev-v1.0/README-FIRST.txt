╔══════════════════════════════════════════════════════════════╗
║  IMIDUS POS Integration - Local Development Package          ║
║  One-Click Setup for Testing & Development                   ║
╚══════════════════════════════════════════════════════════════╝

QUICK START:
  1. Install Docker Desktop: https://docs.docker.com/get-docker/
  2. Double-click START.bat (Windows) or run ./start-local.sh (Linux/Mac)
  3. Wait 2-3 minutes for services to start
  4. Access backend at: http://localhost:5004

WHAT'S INCLUDED:
  ✓ SQL Server 2022 (Express) with INI_Restaurant POS database
  ✓ .NET 9 Backend API (IntegrationService.API)
  ✓ Adminer database management UI
  ✓ Pre-configured connection strings
  ✓ Authorize.net SANDBOX payment processing

DEFAULT CREDENTIALS:
  SQL Server:
    - Server: localhost:1433
    - Username: sa
    - Password: YourStrong@Passw0rd
  
  Backend API:
    - URL: http://localhost:5004
    - Swagger: http://localhost:5004/swagger

DATABASE ARCHITECTURE:
  INI_Restaurant (POS Database - Source of Truth):
    - Read anytime for menu, orders, customers
    - Write only through backend API
    - Contains: tblItem, tblSales, tblCustomer, etc.
  
  IntegrationService (Backend Overlay):
    - Customer profiles, marketing rules
    - Scheduled orders, notifications
    - Idempotency keys, audit logs

TEST CARD NUMBERS (Authorize.net Sandbox):
  Visa: 4111111111111111
  MasterCard: 5424000000000015
  Amex: 378282246310005
  Expiry: Any future date (e.g., 12/30)
  CVV: Any 3-4 digits

IMPORTANT NOTES:
  ⚠ This package is for LOCAL TESTING ONLY
  ⚠ Default passwords should be changed for production
  ⚠ Never commit real credentials to version control
  ⚠ POS database schema should NEVER be modified

TROUBLESHOOTING:
  Port 1433 or 5004 already in use?
    → Stop other SQL Server / applications using these ports
  
  Database restore fails?
    → Ensure INI_Restaurant.Bak is in db/backups/ folder
    → Run: ./scripts/restore-database.sh
  
  API won't start?
    → Check logs: docker-compose logs api
    → Restart: docker-compose restart api

SUPPORT:
  See full documentation: local-dev/README.md
  Check AGENTS.md in project root

═══════════════════════════════════════════════════════════════
Generated: $(date)
Package: IMIDUS POS Integration Local Development
Version: ${VERSION}
═══════════════════════════════════════════════════════════════
