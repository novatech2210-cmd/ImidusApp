@echo off
echo ==========================================
echo   IMIDUS POS Integration - Local Dev
echo ==========================================
echo.
echo Starting services... This may take 2-3 minutes.
echo.

REM Check if Docker is installed
docker --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Docker is not installed.
    echo Please install Docker Desktop from:
    echo https://docs.docker.com/get-docker/
    pause
    exit /b 1
)

REM Check if Docker Compose is installed
docker-compose --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Docker Compose is not installed.
    pause
    exit /b 1
)

echo [1/3] Starting Docker services...
docker-compose up -d

echo [2/3] Waiting for SQL Server...
timeout /t 30 /nobreak >nul

echo [3/3] Checking if database exists...
docker exec imidus-sqlserver /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "YourStrong@Passw0rd" -C -Q "SELECT name FROM sys.databases WHERE name = 'INI_Restaurant'" | findstr "INI_Restaurant" >nul

if errorlevel 1 (
    echo.
    echo Database not found. Restoring from backup...
    bash scripts/restore-database.sh
) else (
    echo Database already restored.
)

echo.
echo ==========================================
echo   Services Ready!
echo ==========================================
echo.
echo Backend API:    http://localhost:5004
echo Health Check:   http://localhost:5004/health
echo Swagger UI:     http://localhost:5004/swagger
echo Database UI:    http://localhost:8080
echo.
echo Press any key to open Swagger UI...
pause >nul
start http://localhost:5004/swagger
