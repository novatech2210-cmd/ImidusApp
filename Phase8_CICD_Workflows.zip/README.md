# TOAST Platform - CI/CD Workflows

## Overview

This package contains GitHub Actions workflows for automated builds and AWS S3 delivery.

## Workflows

| Workflow | Purpose | Triggers |
|----------|---------|----------|
| `android-build.yml` | Build Android APK | push main, tags, workflow_dispatch |
| `ios-build.yml` | Build iOS IPA | push main, tags, workflow_dispatch |
| `web-build.yml` | Build Next.js web app | push main, tags, workflow_dispatch |
| `backend-build.yml` | Build .NET backend | push main, tags, workflow_dispatch |
| `s3-upload.yml` | Reusable S3 upload | Called by other workflows |

## S3 Delivery Structure

```
s3://inirestaurant/Novatech/
├── builds/
│   ├── android/
│   │   ├── toast-v{VERSION}-build{NUMBER}.apk
│   │   └── latest.apk
│   ├── ios/
│   │   ├── toast-v{VERSION}-build{NUMBER}.ipa
│   │   └── latest.ipa
│   ├── web/
│   │   └── web-v{VERSION}-build{NUMBER}.zip
│   └── backend/
│       └── backend-v{VERSION}-build{NUMBER}.zip
└── Documentation/
```

## Required GitHub Secrets

| Secret | Purpose |
|--------|---------|
| `AWS_ACCESS_KEY_ID` | S3 bucket access |
| `AWS_SECRET_ACCESS_KEY` | S3 bucket access |
| `ANDROID_KEYSTORE_BASE64` | Android signing |
| `KEYSTORE_PASSWORD` | Android signing |
| `KEY_ALIAS` | Android signing |
| `KEY_PASSWORD` | Android signing |
| `IOS_P12_CERTIFICATE_BASE64` | iOS signing |
| `IOS_P12_PASSWORD` | iOS signing |
| `IOS_PROVISIONING_PROFILE` | iOS signing |
| `KEYCHAIN_PASSWORD` | Temporary keychain |
| `APPLE_TEAM_ID` | iOS distribution |
| `PROVISIONING_PROFILE_NAME` | iOS distribution |
| `APP_STORE_KEY_ID` | TestFlight (optional) |
| `APP_STORE_ISSUER_ID` | TestFlight (optional) |
| `APP_STORE_API_KEY` | TestFlight (optional) |

## Installation

1. Copy `.github/workflows/` to your repository root
2. Configure GitHub Secrets in repository settings
3. Ensure pnpm-lock.yaml exists in mobile/ and web/ directories
4. Push to main branch to trigger builds

## Manual Triggers

All workflows support `workflow_dispatch` for manual builds:

1. Go to Actions tab in GitHub
2. Select desired workflow
3. Click "Run workflow"
4. Configure options and run

---

*TOAST Platform • IMIDUS Technologies • Novatech 2026*
